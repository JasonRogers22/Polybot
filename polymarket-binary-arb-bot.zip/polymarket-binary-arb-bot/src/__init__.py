"""Polymarket Binary Arbitrage Bot - Main package."""
from .bot import TradingBot
from .config import Config, Mode, load_config
from .gamma_client import GammaClient
from .websocket_client import MarketWebSocket, OrderbookSnapshot
from .risk import RiskManager, PositionManager
from .strategies import BinaryParityArbStrategy, MarketState, StrategySignal

__version__ = "1.0.0"

__all__ = [
    'TradingBot',
    'Config',
    'Mode',
    'load_config',
    'GammaClient',
    'MarketWebSocket',
    'OrderbookSnapshot',
    'RiskManager',
    'PositionManager',
    'BinaryParityArbStrategy',
    'MarketState',
    'StrategySignal'
]
